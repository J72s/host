const { MessageActionRow, MessageButton } = require('discord.js');
const strings = require("../strings.json");
const allowedUsers = require("../allowed.json").allowed;

let monitoring = false; // Variable to track whether monitoring is active
let gameId = null; // Variable to store the ID of the game message
const buttonId = '1247897970817503350 '; // Replace 'BUTTON_ID' with the ID of the button to click

/** 
 * @description Enable reaction monitoring
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args arguments passed with the command
 */
module.exports.run = async (client, message, args) => {
    // Check if the message is sent in a guild
    if (!message.guild) {
        return message.channel.send(strings.notInGuild);
    }

    // Check if the message author is allowed to enable reaction monitoring
    if (!allowedUsers.includes(message.author.id)) {
        return message.channel.send(strings.noPermission);
    }

    // Enable or disable monitoring
    if (args[0] === 'start') {
        monitoring = true;
        const gameMessage = await message.channel.send(strings.monitoringStarted);
        gameId = gameMessage.id;
        // Send a button to join the game
        const joinButton = new MessageButton()
            .setCustomId(buttonId)
            .setLabel('Join Game')
            .setStyle('PRIMARY');
        const row = new MessageActionRow().addComponents(joinButton);
        await gameMessage.edit({ components: [row] });
    } else if (args[0] === 'stop') {
        monitoring = false;
        gameId = null;
        message.channel.send(strings.monitoringStopped);
    } else {
        message.channel.send(strings.invalidArgument);
    }
};

// Event listener for button click
module.exports.listen = (client) => {
    client.on('interactionCreate', async interaction => {
        if (!interaction.isButton()) return;
        if (interaction.customId === buttonId && interaction.message.id === gameId) {
            // Simulate clicking the button
            await interaction.reply('Clicked the button to join the game!');
            console.log('Button clicked successfully.');
        }
    });
};

module.exports.names = {
    list: ["roulet", "roulette"]
};
