const fs = require('fs');
const path = require('path');
const strings = require("../strings.json");
const utils = require("../utils");
const allowedUsers = require("../allowed.json").allowed;

// Load fast.json
const fastWords = require("../fast.json");

/** 
 * @description Start a game where users have 20 seconds to guess a random word from fast.json
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args arguments passed with the command
 */
module.exports.run = async (client, message, args) => {
    try {
        // Select a random word from fast.json
        const randomWord = fastWords[Math.floor(Math.random() * fastWords.length)];
        
        // Send the word to the channel
        const questionMessage = await message.channel.send(`**اسرع شخص يكتب:**  [ ${randomWord} ] `);
        
        // Allow users 20 seconds to respond
        const filter = response => response.content.toLowerCase() === randomWord.toLowerCase();
        const collector = message.channel.createMessageCollector({ filter, time: 20000 });
        
        // Listen for responses
        collector.on('collect', (response) => {
            // Mention the user and declare them as the winner
            message.channel.send(`**Congratulations ${response.author}, you got it right ✅**`);
            collector.stop('answered');
        });
        
        // If no one responds within the time limit, declare that no one won
        collector.on('end', (collected, reason) => {
            if (reason === 'time') {
                message.channel.send("**Time's up! No one guessed the word.**");
            }
        });

    } catch (error) {
        // Log the error
        console.error("Error occurred during the game:", error);
        message.channel.send(strings.errorStartingGame);
    }
};

module.exports.names = {
    list: ["game", "اسرع", "fast"]
};
