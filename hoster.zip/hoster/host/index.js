const { Client, GatewayIntentBits } = require('discord.js');
const { Client: SSHClient } = require('ssh2');
const fs = require('fs');
const readline = require('readline');

const DISCORD_TOKEN = 'your_discord_bot_token';
const SSH_CONFIG = {
    host: '165.227.117.206',
    port: 22,
    username: 'master_yuvkugzzak',
    password: 'Ssaa1122'
};

bot.once('ready', () => {
    console.log(`Logged in as ${bot.user.tag}`);
});

bot.on('messageCreate', async message => {
    if (message.content.startsWith('!runbot')) {
        const tokens = await readTokensFromFile('tokens.txt');
        const randomToken = tokens[Math.floor(Math.random() * tokens.length)];

        // Specify the path to your config file
        const configFilePath = '/path/to/your/bot/config.js';

        updateConfigFile(configFilePath, randomToken, (err) => {
            if (err) {
                message.reply(`Failed to update config file: ${err.message}`);
                return;
            }

            runBotOnSSH(message);
        });
    }
});

async function readTokensFromFile(filePath) {
    const fileStream = fs.createReadStream(filePath);
    const rl = readline.createInterface({
        input: fileStream,
        crlfDelay: Infinity
    });

    const tokens = [];
    for await (const line of rl) {
        tokens.push(line.trim());
    }

    return tokens;
}

function updateConfigFile(configFilePath, newToken, callback) {
    fs.readFile(configFilePath, 'utf8', (err, data) => {
        if (err) {
            callback(err);
            return;
        }

        const updatedConfig = data.replace(/token:\s*".*"/, `token: "${newToken}"`);

        fs.writeFile(configFilePath, updatedConfig, 'utf8', callback);
    });
}

function runBotOnSSH(message) {
    const conn = new SSHClient();
    conn.on('ready', () => {
        console.log('SSH Client :: ready');
        // Replace /home/your_username/bots/bot_script.js with the actual path to your bot script
        conn.exec(`screen -dmS bot_session_name node /home/your_username/bots/bot_script.js`, (err, stream) => {
            if (err) {
                message.reply(`Failed to execute command: ${err.message}`);
                return;
            }
            stream.on('close', (code, signal) => {
                conn.end();
                message.reply('Bot started successfully!');
            }).on('data', data => {
                console.log('STDOUT: ' + data);
            }).stderr.on('data', data => {
                console.error('STDERR: ' + data);
            });
        });
    }).connect(SSH_CONFIG);
}

bot.login(DISCORD_TOKEN);
