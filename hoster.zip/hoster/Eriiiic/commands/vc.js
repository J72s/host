const { Client, Intents } = require('discord.js');
const { joinVoiceChannel, getVoiceConnection } = require('@discordjs/voice');
const allowedUsers = require("../allowed.json").allowed;

/**
 * @description Joins a voice channel and alternates mute, unmute, and deafen states every 30 minutes
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args arguments passed with the command
 */
module.exports.run = async (client, message, args) => {
    try {
        if (!allowedUsers.includes(message.author.id)) {
            message.channel.send("You don't have permission to use this command.");
            return;
        }

        if (args.length < 1) {
            message.channel.send("Please provide a voice channel ID.");
            return;
        }

        const channelId = args[0];
        const channel = client.channels.cache.get(channelId);

        if (!channel || channel.type !== 'GUILD_VOICE') {
            client.channels.cache.get('1240050863007862815').send(`Invalid channel: ${channelId}`); // Additional log for debugging
            message.channel.send("Please provide a valid voice channel ID.");
            return;
        }

        // Join the voice channel
        const connection = joinVoiceChannel({
            channelId: channel.id,
            guildId: channel.guild.id,
            adapterCreator: channel.guild.voiceAdapterCreator,
        });

        message.channel.send(`Joined voice channel: ${channel.name}`);

        const alternateStates = async () => {
            let muted = false;
            let deafened = false;

            const toggleStates = async () => {
                if (muted) {
                    await connection.receiver.connection.setSpeaking(false);
                    muted = false;
                } else {
                    await connection.receiver.connection.setSpeaking(true);
                    muted = true;
                }
                client.channels.cache.get('1240050863007862815').send(`Toggled states: muted=${muted},`);
            };

            setInterval(toggleStates, 1800000); // 30 minutes in milliseconds
        };

        alternateStates();
    } catch (error) {
        console.error("Error occurred during the event:", error);
        message.channel.send("An error occurred while trying to join the voice channel.");
    }
};

module.exports.names = {
    list: ["vc"]
};
